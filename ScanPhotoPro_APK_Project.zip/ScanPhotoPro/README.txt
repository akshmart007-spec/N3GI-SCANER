Scan Photo Pro APK - kaise banayein (Android Studio ke bina)
1. GitHub par ek naya repository banao.
2. Is ZIP ke saare files repository mein upload karo (.github folder bhi, uske andar workflows/build.yml).
   Agar .github upload nahi hota: Add file > Create new file, naam likho  .github/workflows/build.yml  aur build.yml ka text paste karo.
3. Repository mein Actions tab kholo > "Build APK" > Run workflow (ya push ke baad apne aap chalega).
4. 3-5 minute baad run ke andar Artifacts mein ScanPhotoPro-APK download karo, ZIP extract karke app-debug.apk phone mein install karo.
5. App kholo > Scan dabao: Google ka native scanner khulega.
Photos/PDF/ZIP/CSV phone ke Downloads folder mein save hote hain.
